from fastapi import APIRouter, HTTPException, Depends, status
from sqlalchemy.orm import Session
from app.backend.db import get_db
from app.models.task import Task
from app.models.user import User
from app.schemas import CreateTask, UpdateTask

router = APIRouter(prefix="/task", tags=["task"])

# Получение всех заданий
@router.get("/")
def all_tasks(db: Session = Depends(get_db)):
    tasks = db.query(Task).all()
    return tasks

# Получение задания по id
@router.get("/{task_id}")
def task_by_id(task_id: int, db: Session = Depends(get_db)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")
    return task

# Создание нового задания
@router.post("/create")
def create_task(task: CreateTask, user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User was not found")

    new_task = Task(
        title=task.title,
        content=task.content,
        priority=task.priority,
        user_id=user_id,
    )
    db.add(new_task)
    db.commit()
    db.refresh(new_task)
    return {'status_code': status.HTTP_201_CREATED, 'transaction': 'Successful'}

# Обновление задания
@router.put("/update")
def update_task(task_id: int, task_update: UpdateTask, db: Session = Depends(get_db)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")

    task.title = task_update.title
    task.content = task_update.content
    task.priority = task_update.priority
    db.commit()
    return task

# Удаление задания
@router.delete("/delete/{task_id}")
def delete_task(task_id: int, db: Session = Depends(get_db)):
    task = db.query(Task).filter(Task.id == task_id).first()
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")

    db.delete(task)
    db.commit()
    return {"status_code": status.HTTP_200_OK, "message": "Task deleted"}
