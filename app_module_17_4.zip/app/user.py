from fastapi import APIRouter, HTTPException, Depends, status
from sqlalchemy.orm import Session
from app.backend.db import get_db
from app.models.user import User
from app.models.task import Task
from app.schemas import CreateUser, UpdateUser

router = APIRouter(prefix="/user", tags=["user"])

# Получение всех пользователей
@router.get("/")
def all_users(db: Session = Depends(get_db)):
    users = db.query(User).all()
    return users

# Получение пользователя по id
@router.get("/{user_id}")
def user_by_id(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return user

# Создание пользователя
@router.post("/create")
def create_user(user: CreateUser, db: Session = Depends(get_db)):
    new_user = User(
        username=user.username,
        firstname=user.firstname,
        lastname=user.lastname,
        age=user.age,
    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return {'status_code': status.HTTP_201_CREATED, 'transaction': 'Successful'}

# Обновление пользователя
@router.put("/update/{user_id}")
def update_user(user_id: int, user_update: UpdateUser, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    user.firstname = user_update.firstname
    user.lastname = user_update.lastname
    user.age = user_update.age
    db.commit()
    return user

# Удаление пользователя и его задач
@router.delete("/delete/{user_id}")
def delete_user(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    # Удаление всех связанных заданий
    tasks = db.query(Task).filter(Task.user_id == user_id).all()
    for task in tasks:
        db.delete(task)

    db.delete(user)
    db.commit()
    return {"status_code": status.HTTP_200_OK, "message": "User and related tasks deleted"}

# Получение всех задач пользователя
@router.get("/{user_id}/tasks")
def tasks_by_user_id(user_id: int, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.id == user_id).first()
    if user is None:
        raise HTTPException(status_code=404, detail="User not found")

    tasks = db.query(Task).filter(Task.user_id == user_id).all()
    return tasks
